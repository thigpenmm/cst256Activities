<?php

namespace App\Http\Controllers;

use App\Services\Data\Database;
use Illuminate\Support\Facades\Route;

use App\Models\SecurityModel;
use App\Services\Business\SecurityService;
use Illuminate\Http\Request;

class LoginController3 extends Controller
{
    /* public function index(Request $request){
   // Usage of path method
      $path = $request->path();
      echo 'Path Method: '.$path;
      echo '<br>';

      // Usage of is method
      $method = $request->isMethod('get') ? "GET" : "POST";
      echo 'GET or POST Method: '.$method;
      echo '<br>';

      // Usage of url method
      $url = $request->url();
      echo 'URL method: '.$url;
      echo '<br>';

      //reading the form data
      $username = $request->input('username');
      $password = $request->input('password');
      echo "Your username is: " . $username;
      echo '<br>';
      echo "Your password is: " . $password;
      echo '<br>';

      $data = ['username' => $username, 'password' => $password];
          return view('login')->with($data);
    }
*/
    public function index(Request $request)
    {
        $link = new Database();
        $database = $link->getConnection();
            $login = $_POST['username'];
            $password = $_POST['password'];
    
            $sql_statement = "SELECT * FROM `users` WHERE `password` = '$password' AND `username`= '$login' ";
            $result = mysqli_query($database,$sql_statement);
            if ($result) {
                if (mysqli_num_rows($result) == 1) {
                     // Validate the Form Data (note will automatically redirect back to Login View if errors)
               
                      $this->validate($request, $rules);

                    return view('loginPassed');
                } else {
                   return view('login3');
                }
            }
    }

    //Activiy 3 additions
    private function validateForm(Request $request)
    {
        // Setup Data Validation Rules for Login Form
        $rules = ['username' => 'Required | Between:4,10 | Alpha',
                  'password' => 'Required | Between:4,10'];

        // Run Data Validation Rules
        $this->validate($request, $rules);
    
    }
}

