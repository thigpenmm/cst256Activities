<?php
namespace App\Services\Business;

use App\Services\Data\CustomerDAO;
use App\Services\Data\OrderDAO;
use App\Services\Data\Database;

class OrderService
{
    public function createOrder($firstName, $lastName, $product)
    {
        mysqli:: autocommit(FALSE);
        mysqli::begin_transaction();
        try{
        CustomerDAO->addCustomer(); 
        OrderDAO->addOrder();
        mysqli::commit();
        }
        catch (Exception $e){
        mysqli::rollback(); 
         echo "Failed update: " . $e->getMessage();  
        }
    }
}
