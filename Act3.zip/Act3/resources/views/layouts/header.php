 <h2 align= "center">Welcome to Activity 3 </h2>
