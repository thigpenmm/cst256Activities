    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div align="center">

<html lang="en">
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <div align="center">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH C:\MAMP\htdocs\Act2\resources\views/layouts/appmaster.blade.php ENDPATH**/ ?>