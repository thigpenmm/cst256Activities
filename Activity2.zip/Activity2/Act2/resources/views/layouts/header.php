 <h2 align= "center">Welcome to Activity 2 </h2>
