    @include('layouts.header')
    <div align="center">

<html lang="en">
<head>
    <title>@yield('title')</title>
</head>
<body>
    <div align="center">
        @yield('content')
    </div>
</body>
</div>
    @include('layouts.footer')

</html>
