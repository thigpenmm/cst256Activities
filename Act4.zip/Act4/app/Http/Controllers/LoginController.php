<?php

namespace App\Http\Controllers;

use App\Services\Data\Database;
use Illuminate\Support\Facades\Route;

use App\Models\SecurityModel;
use App\Services\Business\SecurityService;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /* public function index(Request $request){
   // Usage of path method
      $path = $request->path();
      echo 'Path Method: '.$path;
      echo '<br>';

      // Usage of is method
      $method = $request->isMethod('get') ? "GET" : "POST";
      echo 'GET or POST Method: '.$method;
      echo '<br>';

      // Usage of url method
      $url = $request->url();
      echo 'URL method: '.$url;
      echo '<br>';

      //reading the form data
      $username = $request->input('username');
      $password = $request->input('password');
      echo "Your username is: " . $username;
      echo '<br>';
      echo "Your password is: " . $password;
      echo '<br>';

      $data = ['username' => $username, 'password' => $password];
          return view('login')->with($data);
    }
*/
    public function login(Request $request)
    {
        $link = new Database();
        $database = $link->getConnection();
        $sql_statement = "SELECT * FROM `users` WHERE `password` = '$password' AND `username`= '$login' ";
        
        $userlogin = new SecurityModel($request->input('username'), $request->input('password'));
        $service = new SecurityService();
        $loginResult = $service->login($userlogin);
        
        if (!$loginResult) {
            return view('loginFailed');
        } else {
            return view('loginPassed');
        }
    }
}

