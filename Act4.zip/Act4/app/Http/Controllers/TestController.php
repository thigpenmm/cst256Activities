<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestController extends Controller
{
    //Activity 1 Test
	public function test() {
		echo "Hello World from Test Controller";
	}
	
	public function test2() {
		return view('helloworld');
	}
}
