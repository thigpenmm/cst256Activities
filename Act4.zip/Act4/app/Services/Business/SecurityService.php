<?php
namespace App\Services\Business;

use App\Services\Data\SecurityDAO;
use App\Models\SecurityModel;

class SecurityService
{
    public function login(SecurityModel $user)
    {
        $service = new SecurityDAO();
        return $service->findUser($user);
    }
}
