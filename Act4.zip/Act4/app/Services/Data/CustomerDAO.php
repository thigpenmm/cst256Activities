<?php
namespace App\Services\Data;


use App\Services\Data\Database;

class CustomerDAO
{
    public function addCustomer($firstName, $lastName)
    {
        $link = new Database();
        $database = $link->getConnection();

        $firstName = $customer->getFirstname();
        $lastName= $customer->getLastname();

        $sql_statement = "INSERT INTO `customer` (`First_Name`,`Last_Name`) VALUES ('$firstName', '$lastName');";
     
        if (mysqli_query($database, $sql_statement)) {
            echo "One customer has been added: " . $firstName . " " . $lastName ."<br><br>";
        } else {
            echo "Error: " . $sql_statement . "<br>" . mysqli_error($database);//error if connection fails
        }
    }
}
