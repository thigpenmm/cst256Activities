<?php
namespace App\Services\Data;


use App\Services\Data\Database;

class OrderDAO
{
    public function addOrder($product)
    {
        $link = new Database();
        $database = $link->getConnection();

        $product = $order->getProduct();
        $custID= $customer->getID();

        $sql_statement = "INSERT INTO `order` (`Product`,`Customer_ID`) VALUES ('$product', '$custID');";
     
        if (mysqli_query($database, $sql_statement)) {
            echo "One order has been added: " . $product. "for customer #" . $custID ."<br><br>";
        } else {
            echo "Error: " . $sql_statement . "<br>" . mysqli_error($database);//error if connection fails
        }
    }
}
