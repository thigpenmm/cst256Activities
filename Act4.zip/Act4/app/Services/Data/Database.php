<?php
namespace App\Services\Data;

class Database
{
    private $username;
    private $password;
    private $db;
    private $host;
    private $port;

    public function __construct()
    {
        $this->host = "localhost";
        $this->username = "root";
        $this->password = "root";
        $this->db = "activity2";
        $this->port= 3307;
    }
    
    public function getConnection()
    {
        $database = mysqli_connect($this->host, $this->username, $this->password, $this->db, $this->port,);
        if ($database === false) {
            die("ERROR: Connection failed: " . mysqli_connect_error());
        }
        return $database;
    }
}