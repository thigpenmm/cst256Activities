<?php $__env->startSection('title', 'Login Page'); ?>
<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>
<head>
<title> Login </title>
</head>
<body>
<div class="container">
<form method="POST" action = "dologin3">
<div class="form-input">
<h1 style="color:gray;"> <br> Sign In</h1>
<input type="text" name="username" placeholder="Enter your Username" required minlength="4" maxlength="10"/>
</div>
<div class="form-input">
<input type="password" name="password" placeholder="Enter your Password"required minlength="4" maxlength="10"/>
</div>
<input type="submit" type="submit" value="LOGIN" class="btn-login" />
<?php
    if($errors->count() != 0)
    {
        echo "<h5>List of Errors</h5>";
        foreach($errors->all() as $message)
        {
            echo $message . "<br/>";
        }
    }
?>

</form>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\Act4\resources\views/login3.blade.php ENDPATH**/ ?>